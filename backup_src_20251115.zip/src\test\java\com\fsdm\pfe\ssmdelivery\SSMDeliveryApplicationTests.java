package com.fsdm.pfe.ssmdelivery;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SSMDeliveryApplicationTests {

}



