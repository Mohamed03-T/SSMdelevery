/*
 *
 *  * @project : SSMDelivery
 *  * @created : 18/05/2024, 20:40
 *  * @modified : 18/05/2024, 20:40
 *  * @description : This file is part of the SSMDelivery project.
 *  * @license : MIT License
 *
 */

package com.fsdm.pfe.ssmdelivery.config;

//@Configuration
//public class AppConfig {
//
//    @Bean
//    public FutureOrPresentValidatorForReadableInstant futureOrPresentValidatorForReadableInstant() {
//        return new FutureOrPresentValidatorForReadableInstant();
//    }
//}


