/*
 *
 *  * @project : SSMDelivery
 *  * @created : 17/05/2024, 16:46
 *  * @modified : 17/05/2024, 16:46
 *  * @description : This file is part of the SSMDelivery project.
 *  * @license : MIT License
 *
 */

package com.fsdm.pfe.ssmdelivery.entity;

import com.fsdm.pfe.ssmdelivery.model.enums.Role;
import com.fsdm.pfe.ssmdelivery.model.enums.UserStatus;
import com.fsdm.pfe.ssmdelivery.model.enums.VehicleType;
import jakarta.persistence.*;
import javassist.SerialVersionUID;
import lombok.*;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Getter
@Setter
@ToString
@RequiredArgsConstructor
@AllArgsConstructor
@Entity
@DiscriminatorValue(Role.VEHICLE_OPERATOR_ROLE)
public class VehicleOperatorEmployee extends Employee implements UserDetails, Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    private String licenseNumber;

    private String vihiculeMtricule;

    @Enumerated(EnumType.STRING)
    private VehicleType vehicleType;


    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        List<GrantedAuthority> authorities = new ArrayList<>();
        authorities.add(new SimpleGrantedAuthority(ROLE_PREFIX + this.getRole()));
        return authorities;
    }

    @Override
    public String getPassword() {
        return super.getPassword();
    }

    @Override
    public String getUsername() {
        return this.getEmail();
    }

    @Override
    public boolean isAccountNonExpired() {
        return !this.getStatus().equals(UserStatus.EXPIRED);
    }

    @Override
    public boolean isAccountNonLocked() {
        return !this.getStatus().equals(UserStatus.LOCKED);
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return this.getStatus() != null && (this.getStatus().equals(UserStatus.ACTIVE));
    }

}



