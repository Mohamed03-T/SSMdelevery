/*
 *
 *  * @project : SSMDelivery
 *  * @created : 16/05/2024, 16:08
 *  * @modified : 16/05/2024, 16:08
 *  * @description : This file is part of the SSMDelivery project.
 *  * @license : MIT License
 *
 */

package com.fsdm.pfe.ssmdelivery.config.jwt;

import org.springframework.stereotype.Component;

@Component
public class JwtUtils {
}



