/*
 * **
 *  * @project : SSMDelivery
 *  * @created : 24/04/2024, 18:01
 *  * @modified : 24/04/2024, 18:01
 *  * @description : This file is part of the SSMDelivery project.
 *  * @license : MIT License
 *  **
 */

INSERT INTO user ( email, password, role,user,customer_number) VALUES ( 'test@test.com', '$2a$10$WjLQwMw.tZbh33vPzhX3iOvr8W9UWJZ3r8SJqTIs3eg1Iwm4hj8HC', 'CUSTOMER','abdelhak',123456);
