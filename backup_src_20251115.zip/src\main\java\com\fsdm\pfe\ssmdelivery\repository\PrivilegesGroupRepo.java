package com.fsdm.pfe.ssmdelivery.repository;

import com.fsdm.pfe.ssmdelivery.entity.PrivilegesGroup;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PrivilegesGroupRepo extends JpaRepository<PrivilegesGroup, Long> {
}



